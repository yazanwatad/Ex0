


#define e 2.7182

double Exponent(int x) {
	int i,negative=0;
	double ex = 1;
	if (x < 0) {
		negative = 1;
		x *= -1;
	}
	for (i = 0; i < x; i++) {
		ex *= e;
	}
	if(negative==1)
		return (1/ex);
	else
		return ex;
}

double Power(double x, int y) {
	int i, negative = 0;
	double pow = 1;
	if (y < 0) {
		negative = 1;
		y *= -1;
	}

	for (i = 0; i < y; i++) {
		pow *= x;
	}
	if (negative==1)
		return (1 / pow);
	else
		return pow;
}