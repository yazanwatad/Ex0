

float add(float x, float y); 
float sub(float x, float y); 
double mul(double x, int y); 
double div(double x, int y); 
double Exponent(int x);
double Power(double x, int y);