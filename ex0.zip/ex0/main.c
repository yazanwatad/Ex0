
#include <stdio.h>
#include "myMath.h"


int main()
{
	double x , f1,f2,f3;
		printf("x:");
		scanf_s("%lf", &x);
		
	f1 = sub(add(Exponent(x) , Power(x, 3)),2);
	printf("%0.4lf\n", f1);
	f2 = add(Power(mul(x,2),2),mul(x,3));
	printf("%0.4lf\n", f2);
	f3 = div(Power(mul(x, 4),3), sub(5,mul(x, 2)));
	printf("%0.4lf", f3);
	
	return 0;
}
